const db = require('./db');
accountDetails = {
    1000: { id: 1000, username: "userone", phone: 9445656432, password: "user1" },
    1001: { id: 1001, username: "usertwo", phone: 884565732, password: "user2" },
    1002: { id: 1002, username: "userhree", phone: 7945656432, password: "user3" },
    1003: { id: 1003, username: "userfour", phone: 6345656432, password: "user4" },
    1004: { id: 1004, username: "userfive", phone: 9469656432, password: "user5" },
    1005: { id: 1005, username: "usersix", phone: 9444156432, password: "user6" },
};

let stockdetails = {
    1100: { sid: 1100, id: 1000, milk_amount: 4, amount: 100 }
}
let purchasedetails = {
    1: { phone: 1, id: 1000, pmilk_amount: 2, pamount: 100 }
}
let salesdetails = {
    1: { sid: 1, id: 1000, smilk_amount: 3, samount: 150 }
}
let currentUser;



const stock = (req,time) => {
    const phone = req.session.currentUser.phone;
    return db.Stock.findOne({
        phone
    }).then(stock => {
        console.log(stock);
        if (stock) {
            return {
                status: false,
                statusCode: 422,
                message: "Stock is exists"
            }
        } else {
            const newStock = new db.Stock({
                phone,
                quantity: 0,
                amount: 0,
                time

            });
            newStock.save();
            return {
                status: true,
                statusCode: 200,
                message: "stock insert successful"
            }

        }
    })

}


const getstock = (req) => {

    const phone = req.session.currentUser.phone;
    return db.Stock.findOne({

        phone
        
    }).then(user => {
       console.log(user);
        return {
            status: true,
            statusCode: 200,
            message: "stock Data",
            stock:user
        }

    })



}



const purchase = (req, quantity,reading,test,amount, time) => {
    if (!req.session.currentUser) {
        return {
            status: false,
            message: "Please Login ",
            statusCode: 401
        };
    }
    const quan = parseInt(quantity);
    const amt = parseInt(amount);
    const phone = req.session.currentUser.phone;
    return db.Stock.findOne({
        phone
    }).then(stock => {
        if (!stock) {
            return {
                status: false,
                statusCode: 422,
                message: "There is no stock with this Phone Number"
            }

        }
        console.log(stock.quantity);
        if (stock.amount > amt) 
        {
            stock.quantity += quan;
            stock.amount -= amt;
            stock.time=time;
            stock.save()
            db.Sales.findOne({
            phone
        }).then(sales => {

            console.log(sales);
                const Purchase = new db.Purchase({
                    phone,
                    quantity,
                    reading,
                    test,
                    amount,
                    time
                })
                Purchase.save()
        })
            
    } 
            else {
                return {
                    status: false,
                    statusCode: 422,
                    message: "No Enough Money "
                }
            }
  return {
            status: true,
            statusCode: 200,
            message: "Milk is purchased with Stock update "
         } 
})


}



const getpurchase = (req) => {
    const phone = req.session.currentUser.phone;
    return db.Purchase.find({

        phone
        
    }).then(user => {
       console.log(user);
        return {
            status: true,
            statusCode: 200,
            message: "Data Purchase",
            data:user
        }

    })



}



const deletepurchase = (id) => {
    return db.Purchase.deleteOne({
        _id: id
    }).then(user => {
        if (!user) {
            return {
                status: false,
                statusCode: 422,
                message: "user not exist"

            }
        }
        return {
            status: true,
            statusCode: 200,
            message: "Deleted  Successful "

        }
    })

}




const resetstockpur = (req, quantity,amount,time) => {
    if (!req.session.currentUser) {
        return {
            status: false,
            message: "Please Login ",
            statusCode: 401
        };
    }
    const quan = parseInt(quantity);
    const amt = parseInt(amount);
    const phone = req.session.currentUser.phone;
    return db.Stock.findOne({
        phone
    }).then(stock => {
        if (!stock) {
            return {
                status: false,
                statusCode: 422,
                message: "There is no stock with this Phone Number"
            }

        }
        console.log(stock.quantity);
      
            stock.quantity -= quan;
            stock.amount += amt;
            stock.time=time;
            stock.save()
        
  return {
            status: true,
            statusCode: 200,
            message: "Milk is deleted with Stock update "
         } 
})


}





const sales = (req, quantity, amount, time) => {

    if (!req.session.currentUser) {
        return {
            status: false,
            message: "Please Login ",
            statusCode: 401
        };
    }
    const quan = parseInt(quantity);
    const amt = parseInt(amount);
    const phone = req.session.currentUser.phone;
    return db.Stock.findOne({
        phone
    }).then(stock => {
        if (!stock) {
            return {
                status: false,
                statusCode: 422,
                message: "There is no stock with this Phone Number"
            }

        }
        console.log(stock.quantity);
        if (stock.quantity > quan) 
        {
            stock.quantity -= quan;
            stock.amount += amt;
            stock.time=time;
            stock.save()
            db.Sales.findOne({
            phone
        }).then(sales => {

            console.log(sales);
                const Sales = new db.Sales({
                    phone,
                    quantity,
                    amount,
                    time
                })
                Sales.save()
        })
            
    } 
            else {
                return {
                    status: false,
                    statusCode: 422,
                    message: "There is no entered stock of Milk "
                }
            }
  return {
            status: true,
            statusCode: 200,
            message: "Milk is saled with Stock update "
         } 
})

    // let datast = stockdetails
    // var ma = parseInt(smilk_amount);
    // var amt = parseInt(samount);
    // if (sid in salesdetails) {
    //     return {
    //         status: false,
    //         message: "data exists",
    //     }
    // } else {
    //     stid = 1100;
    //     var stock_milk = datast[stid].milk_amount;
    //     if (stock_milk >= smilk_amount) {
    //         salesdetails[sid] = {
    //             sid,
    //             id,
    //             smilk_amount,
    //             samount
    //         }
    //         datast[stid].milk_amount -= ma
    //         datast[stid].amount += amt
    //         console.log(purchasedetails);
    //         console.log(stockdetails);
    //         return {
    //             status: true,
    //             message: "Sales Action is added  and stock is updated"
    //         }
    //     } else {
    //         return {
    //             status: false,
    //             message: "  No stock"
    //         }

    //     }

    // }


}



const getsales = (req) => {

    const phone = req.session.currentUser.phone;
    
    return db.Sales.find({

        phone
        
    }).then(user => {
       console.log(user);
        return {
            status: true,
            statusCode: 200,
            message: "Milk is Saled",
            data:user
        }

    })



}




const deletesales = (id) => {
    return db.Sales.deleteOne({
        _id: id
    }).then(user => {
        if (!user) {
            return {
                status: false,
                statusCode: 422,
                message: "data not exist"

            }
        }
        return {
            status: true,
            statusCode: 200,
            message: "Deleted  Successful "

        }
    })

}





    const resetstocksale = (req, quantity,amount,time) => {
        if (!req.session.currentUser) {
            return {
                status: false,
                message: "Please Login ",
                statusCode: 401
            };
        }
        const quan = parseInt(quantity);
        const amt = parseInt(amount);
        const phone = req.session.currentUser.phone;
        return db.Stock.findOne({
            phone
        }).then(stock => {
            if (!stock) {
                return {
                    status: false,
                    statusCode: 422,
                    message: "There is no stock with this Phone Number"
                }
    
            }
            console.log(stock.quantity);
          
                stock.quantity += quan;
                stock.amount -= amt;
                stock.time=time;
                stock.save()
            
      return {
                status: true,
                statusCode: 200,
                message: "sales is deleted with Stock update "
             } 
    })
    
    
    }

const register = (phone, username, address, password) => {

    return db.User.findOne({
        phone
    }).then(user => {
        console.log(user);
        if (user) {
            return {
                status: false,
                statusCode: 422,
                message: "user exists"
            }

        } else {
            const newUser = new db.User({
                phone,
                username,
                address,
                password

            });
            newUser.save();
            return {
                status: true,
                statusCode: 200,
                message: "Registration successful"
            }
        }

    })



}


const editprofile=(req,username,address,password) => {
    const phone = req.session.currentUser.phone;
    return  db.User.updateOne({phone:phone},{$set:{username:username,
        address:address,password:password}
    }).then(data => {
        if (!phone) {
            return {
                status: false,
                statusCode: 422,
                message: "There is no data"
            }

        }
        else{
             return {
                status: true,
                statusCode: 200,
                message: "Data Updated"
            }
        }
    })
}

const editpurchase=(req,id,quantity,reading,test,amount,time) => {
    const quan = parseInt(quantity);
    const amt = parseInt(amount);
    const phone = req.session.currentUser.phone;
    return db.Stock.findOne({
        phone
    }).then(stock => {
        if (!stock) {
            return {
                status: false,
                statusCode: 422,
                message: "There is no stock with this Phone Number"
            }

        }
        console.log(stock.quantity);
        if (stock.amount > amt) 
        {
            stock.quantity += quan;
            stock.amount -= amt;
            stock.time=time;
            stock.save()
            db.Purchase.updateOne({_id:id},{$set:{phone:phone,quantity:quantity,reading:reading,
                test:test,amount:amount,time:time}
        }).then(purchase => {
            console.log(purchase);
            
        })
            
    } 
     else {
                return {
                    status: false,
                    statusCode: 422,
                    message: "No Enough Money "
                }
            }
            return {
                status: true,
                statusCode: 200,
                message: "Milk is purchased with Stock update "
            } 
})
    

    
   
 }


const editsales=(req,id,quantity,amount,time) => {
  

    const quan = parseInt(quantity);
    const amt = parseInt(amount);
    const phone = req.session.currentUser.phone;
    return db.Stock.findOne({
        phone
    }).then(stock => {
        if (!stock) {
            return {
                status: false,
                statusCode: 422,
                message: "There is no stock with this Phone Number"
            }

        }
        console.log(stock.quantity);
        if (stock.quantity > quan) 
        {
            stock.quantity -= quan;
            stock.amount += amt;
            stock.time=time;
            stock.save()
            db.Sales.updateOne({_id:id},{$set:{phone:phone,quantity:quantity,amount:amount,time:time}
        }).then(Sales => {
            console.log(Sales);
            
        })
            
    } 
     else {
                return {
                    status: false,
                    statusCode: 422,
                    message: "No Enough Stock "
                }
            }
            return {
                status: true,
                statusCode: 200,
                message: "Milk  Sale and Stock is updated "
            } 
})
  
  
  
  
  
  
    // const phone = req.session.currentUser.phone;
    // return  db.Sales.updateOne({_id:id},{$set:{phone:phone,quantity:quantity,
    //     amount:amount,time:time}
    // }).then(data => {
    //     if (!id) {
    //         return {
    //             status: false,
    //             statusCode: 422,
    //             message: "There is no data"
    //         }

    //     }
    //     else{
    //          return {
    //             status: true,
    //             statusCode: 200,
    //             message: "Data Updated"
    //         }
    //     }
    // })
}


const getuser = (req) => {
    const phone = req.session.currentUser.phone;
    return db.User.findOne({
       phone
         }).then(user => {
       console.log(user);
        return {
            status: true,
            statusCode: 200,
            message: " Data User",
            user:user
            
        }

    })



}





const login = (req, phone, password) => {

    return db.User.findOne({

        phone,
        password
    }).then(user => {
        if (user) {
            req.session.currentUser = user
             

            return {
                status: true,
                statusCode: 200,
                message: "login Successful",
                name: user.username,
                phone: user.phone,
                id: user._id

            }
        }
        return {
            status: false,
            statusCode: 422,
            message: "Invalid Login"
        }

    })



}




module.exports = {
    register,
    stock,
    login,
    purchase,
    sales,
    getpurchase,
    getuser,
    getsales,
    getstock,
    editpurchase,
    deletepurchase,
    deletesales,
    editsales,
    editprofile,
    resetstockpur,
    resetstocksale
    
};