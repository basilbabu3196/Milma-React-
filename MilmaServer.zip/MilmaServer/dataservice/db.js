const mongoose = require('mongoose');
mongoose.connect("mongodb://localhost:27017/milk_server", {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
const Stock = mongoose.model('Stock', {
    phone: String,
    quantity: Number,
    amount: Number,
    time: String

})
const User = mongoose.model('User', {
    phone: String,
    username: String,
    address: String,
    password: String

})
const Purchase = mongoose.model('Purchase', {
    phone: String,
    quantity: Number,
    reading:Number,
    test:Number,
    amount: Number,
    time: String

})

const Sales = mongoose.model('Sales', {
    phone: String,
    quantity: Number,
    amount: Number,
    time: String

})

module.exports = {
    Stock,
    User,
    Purchase,
    Sales
}