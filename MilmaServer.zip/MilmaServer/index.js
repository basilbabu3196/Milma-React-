const express = require("express");
const session = require("express-session");
const cors = require('cors');
const dataservice = require("./dataservice/dataservice.js");
const { json } = require("express");
const app = express();
app.use(express.json());
app.use(session({
    secret: 'randomsecurestring',
    resave: false,
    saveUninitialized: false
}))

app.use(cors({
    origin: 'http://localhost:3000',
    credentials: true
})) 
const authMiddleware = (req, res, next) => {
    if (!req.session.currentUser) {
        return res.json({
            status: false,
            statusCode: 401,
            message: "please login"
        })
    } else {
        next()
    }
}
const auMiddleware = (req, res, next) => {
   
        next()
    }


app.get("/getpurchase", authMiddleware,(req, res) => {
   
    dataservice.getpurchase(req)
     .then(result => {
            res.status(result.statusCode).json(result)
        })
});

app.get("/getsales", authMiddleware,(req, res) => {
   
    dataservice.getsales(req)
     .then(result => {
            res.status(result.statusCode).json(result)
        })
});

app.get("/getstock",authMiddleware, (req, res) => {
   
    dataservice.getstock(req)
     .then(result => {
            res.status(result.statusCode).json(result)
        })
});

app.get("/getuser",authMiddleware,(req, res) => {
    console.log(req.body);
    dataservice.getuser(req)
     .then(result => {
            res.status(result.statusCode).json(result)
        })
});
app.post("/", (req, res) => {
    res.status(200).send("post method");
})


app.post('/register', (req, res) => {
    console.log(req.body);
    dataservice.register(req.body.phone, req.body.username, req.body.address, req.body.password)

    .then(result => {
            res.status(result.statusCode).json(result)
        })
        //console.log(res.status(result.statusCode).json(result));
})

app.post('/stock',(req, res) => {
    console.log(req.body);
    dataservice.stock(
            req,
            req.body.phone,
            req.body.time
        )
        .then(result => {
            res.status(result.statusCode).json(result)
        })
})


app.post("/purchase", authMiddleware, (req, res) => {
    
    console.log(req.body);
    dataservice.purchase(
            req,
            req.body.quantity,
            req.body.reading,
            req.body.test,
            req.body.amount,
            req.body.time
        )
        .then(result => {
            res.status(result.statusCode).json(result)
        })
        // console.log(res.send(result.message));
});




app.post("/sales", authMiddleware, (req, res) => {
    console.log(req.body);
    dataservice.sales(
            req,
            req.body.quantity,
            req.body.amount,
            req.body.time

        )
        .then(result => {
            res.status(result.statusCode).json(result)

        })
        // console.log(res.send(result.message));
});

app.post("/login", (req, res) => {
    console.log(req.body);
    const result = dataservice.login(
            req,
            req.body.phone,
            req.body.password
        )
        .then(result => {

            res.status(result.statusCode).json(result)
        })
        //console.log(res.send(result.message));
});




app.listen(8000, () => {
    console.log("app started at port 8000");
});
